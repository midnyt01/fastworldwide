import Topbar from "../../../component/admin-panel-components/admin-topbar/topbar.component";
import Enquiry from "../../../component/admin-panel-components/site-management/enquiry.component";

const EnquiryPage = () => {

    return (
        <div>
            <Topbar />
            <Enquiry />
        </div>
    )
}

export default EnquiryPage;