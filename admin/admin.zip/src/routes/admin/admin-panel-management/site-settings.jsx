import Topbar from "../../../component/admin-panel-components/admin-topbar/topbar.component";
import SiteSettings from "../../../component/admin-panel-components/site-management/site-settings.component"

const SiteSettingPage = () => {

    return (
        <div>
            <Topbar />
            < SiteSettings />
        </div>
    )
}

export default SiteSettingPage;